var searchData=
[
  ['compressor_85',['Compressor',['../class_frostweep_games_1_1_voice_pro_1_1_compressor.html',1,'FrostweepGames::VoicePro']]],
  ['constants_86',['Constants',['../class_frostweep_games_1_1_voice_pro_1_1_constants.html',1,'FrostweepGames::VoicePro']]]
];
