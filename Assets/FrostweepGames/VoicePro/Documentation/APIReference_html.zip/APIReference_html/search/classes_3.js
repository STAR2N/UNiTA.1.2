var searchData=
[
  ['inetworkactor_88',['INetworkActor',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html',1,'FrostweepGames::VoicePro']]],
  ['inetworkprovider_89',['INetworkProvider',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html',1,'FrostweepGames::VoicePro']]]
];
