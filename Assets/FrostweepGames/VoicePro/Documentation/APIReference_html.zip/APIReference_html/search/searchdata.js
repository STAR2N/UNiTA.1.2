var indexSectionsWithContent =
{
  0: "abcdefghilnprsuvw",
  1: "aceilnrsvw",
  2: "f",
  3: "aceilnprsvw",
  4: "bcdfghirsu",
  5: "cdrsv",
  6: "n",
  7: "pu",
  8: "inps",
  9: "nrs"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "enums",
  7: "enumvalues",
  8: "properties",
  9: "events"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Enumerations",
  7: "Enumerator",
  8: "Properties",
  9: "Events"
};

