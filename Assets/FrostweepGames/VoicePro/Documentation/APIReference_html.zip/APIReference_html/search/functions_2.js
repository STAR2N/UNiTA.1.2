var searchData=
[
  ['decompress_119',['Decompress',['../class_frostweep_games_1_1_voice_pro_1_1_compressor.html#a75937b657da1662341c8d4a74eeeca5e',1,'FrostweepGames::VoicePro::Compressor']]],
  ['dispose_120',['Dispose',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#adf9bb51fb0507f0cb8e0508a98874e85',1,'FrostweepGames.VoicePro.INetworkProvider.Dispose()'],['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html#aa7407d58a9fceecf0c4c7dbb2ba63478',1,'FrostweepGames.VoicePro.Speaker.Dispose()']]]
];
