var searchData=
[
  ['unregister_139',['Unregister',['../class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a0d9191d9f75e229d27b3d163f2c66356',1,'FrostweepGames::VoicePro::NetworkRouter']]],
  ['update_140',['Update',['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html#a868e9d2986da9ebef3d308e0208c4221',1,'FrostweepGames::VoicePro::Speaker']]]
];
