var searchData=
[
  ['init_126',['Init',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#af7e52b4887ac0cc25bccde6d86a0801d',1,'FrostweepGames::VoicePro::INetworkProvider']]],
  ['isvoicedetected_127',['IsVoiceDetected',['../class_frostweep_games_1_1_voice_pro_1_1_voice_detector.html#a9924d221728e924ac2c0087812ac6fd8',1,'FrostweepGames::VoicePro::VoiceDetector']]]
];
