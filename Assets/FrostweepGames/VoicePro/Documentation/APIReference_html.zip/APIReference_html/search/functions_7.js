var searchData=
[
  ['refreshmicrophones_128',['RefreshMicrophones',['../class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a1096dfa5011bcacdb390e7248ddbdd51',1,'FrostweepGames::VoicePro::Recorder']]],
  ['register_129',['Register',['../class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a647f4175387305677b0c3ba7b86b6193',1,'FrostweepGames::VoicePro::NetworkRouter']]]
];
