var searchData=
[
  ['speaker_95',['Speaker',['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html',1,'FrostweepGames::VoicePro']]]
];
