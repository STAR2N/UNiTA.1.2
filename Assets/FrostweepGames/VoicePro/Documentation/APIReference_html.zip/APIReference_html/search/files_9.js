var searchData=
[
  ['voicedetector_2ecs_115',['VoiceDetector.cs',['../_voice_detector_8cs.html',1,'']]]
];
