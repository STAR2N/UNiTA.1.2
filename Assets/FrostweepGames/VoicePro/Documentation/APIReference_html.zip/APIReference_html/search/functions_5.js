var searchData=
[
  ['handlerawdata_125',['HandleRawData',['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html#a3494773dc83283f165c7abcb093f522a',1,'FrostweepGames::VoicePro::Speaker']]]
];
