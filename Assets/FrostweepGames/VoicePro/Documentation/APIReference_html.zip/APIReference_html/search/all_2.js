var searchData=
[
  ['chunksize_3',['ChunkSize',['../class_frostweep_games_1_1_voice_pro_1_1_constants.html#a3262a82807213b29dd92ffe21d1ca4ef',1,'FrostweepGames::VoicePro::Constants']]],
  ['compress_4',['Compress',['../class_frostweep_games_1_1_voice_pro_1_1_compressor.html#a5531abf7acaccbfc30911eb80f5a79a7',1,'FrostweepGames::VoicePro::Compressor']]],
  ['compressor_5',['Compressor',['../class_frostweep_games_1_1_voice_pro_1_1_compressor.html',1,'FrostweepGames::VoicePro']]],
  ['compressor_2ecs_6',['Compressor.cs',['../_compressor_8cs.html',1,'']]],
  ['constants_7',['Constants',['../class_frostweep_games_1_1_voice_pro_1_1_constants.html',1,'FrostweepGames::VoicePro']]],
  ['constants_2ecs_8',['Constants.cs',['../_constants_8cs.html',1,'']]]
];
