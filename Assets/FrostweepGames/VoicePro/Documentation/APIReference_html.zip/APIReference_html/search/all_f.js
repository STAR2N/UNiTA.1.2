var searchData=
[
  ['voicedetectionenabled_78',['voiceDetectionEnabled',['../class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a1daba4677d622c7b69fa4ee18b57ce8f',1,'FrostweepGames::VoicePro::Recorder']]],
  ['voicedetectionthreshold_79',['voiceDetectionThreshold',['../class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a96976a319f7860643dc833bf31211c1e',1,'FrostweepGames::VoicePro::Recorder']]],
  ['voicedetector_80',['VoiceDetector',['../class_frostweep_games_1_1_voice_pro_1_1_voice_detector.html',1,'FrostweepGames::VoicePro']]],
  ['voicedetector_2ecs_81',['VoiceDetector.cs',['../_voice_detector_8cs.html',1,'']]]
];
