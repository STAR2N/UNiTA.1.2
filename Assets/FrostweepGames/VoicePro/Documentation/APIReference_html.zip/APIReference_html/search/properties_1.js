var searchData=
[
  ['name_160',['Name',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#a5f59f22cf75a9fe49da155b2583d45e8',1,'FrostweepGames.VoicePro.INetworkActor.Name()'],['../class_frostweep_games_1_1_voice_pro_1_1_speaker.html#a10c8d6c75af0db399357981ef7f50cf2',1,'FrostweepGames.VoicePro.Speaker.Name()']]],
  ['networktype_161',['NetworkType',['../class_frostweep_games_1_1_voice_pro_1_1_network_router.html#ad3df36e8cd9f947199d7fb1322a4aea7',1,'FrostweepGames::VoicePro::NetworkRouter']]]
];
