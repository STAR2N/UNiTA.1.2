var searchData=
[
  ['getconnectiontoserver_18',['GetConnectionToServer',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a384914ef0622fd98bb61422cacaec48c',1,'FrostweepGames.VoicePro.INetworkProvider.GetConnectionToServer()'],['../class_frostweep_games_1_1_voice_pro_1_1_network_router.html#aef8b3b4136a67cba6b339c8f14199f66',1,'FrostweepGames.VoicePro.NetworkRouter.GetConnectionToServer()']]],
  ['getcurrentroomname_19',['GetCurrentRoomName',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a372e33d5e8ef9650f066355fa7d24e3b',1,'FrostweepGames.VoicePro.INetworkProvider.GetCurrentRoomName()'],['../class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a2ce15903e968d5160432ad955a8bf432',1,'FrostweepGames.VoicePro.NetworkRouter.GetCurrentRoomName()']]],
  ['getnetworkstate_20',['GetNetworkState',['../interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a6ac802aa5fa051e607c8ad754677ae2e',1,'FrostweepGames.VoicePro.INetworkProvider.GetNetworkState()'],['../class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a88e6e6a3c31ece780c4f80f7b3b2ad79',1,'FrostweepGames.VoicePro.NetworkRouter.GetNetworkState()']]]
];
