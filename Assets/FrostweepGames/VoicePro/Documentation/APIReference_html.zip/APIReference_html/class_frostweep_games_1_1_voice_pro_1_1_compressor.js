var class_frostweep_games_1_1_voice_pro_1_1_compressor =
[
    [ "Compress", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html#a5531abf7acaccbfc30911eb80f5a79a7", null ],
    [ "Decompress", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html#a75937b657da1662341c8d4a74eeeca5e", null ]
];