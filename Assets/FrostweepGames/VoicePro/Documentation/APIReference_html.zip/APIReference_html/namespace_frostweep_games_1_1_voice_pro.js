var namespace_frostweep_games_1_1_voice_pro =
[
    [ "AudioConverter", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter.html", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter" ],
    [ "Compressor", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html", "class_frostweep_games_1_1_voice_pro_1_1_compressor" ],
    [ "Constants", "class_frostweep_games_1_1_voice_pro_1_1_constants.html", "class_frostweep_games_1_1_voice_pro_1_1_constants" ],
    [ "Enumerators", "class_frostweep_games_1_1_voice_pro_1_1_enumerators.html", "class_frostweep_games_1_1_voice_pro_1_1_enumerators" ],
    [ "INetworkActor", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor" ],
    [ "INetworkProvider", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider" ],
    [ "Listener", "class_frostweep_games_1_1_voice_pro_1_1_listener.html", "class_frostweep_games_1_1_voice_pro_1_1_listener" ],
    [ "NetworkRouter", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html", "class_frostweep_games_1_1_voice_pro_1_1_network_router" ],
    [ "Recorder", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html", "class_frostweep_games_1_1_voice_pro_1_1_recorder" ],
    [ "Speaker", "class_frostweep_games_1_1_voice_pro_1_1_speaker.html", "class_frostweep_games_1_1_voice_pro_1_1_speaker" ],
    [ "VoiceDetector", "class_frostweep_games_1_1_voice_pro_1_1_voice_detector.html", "class_frostweep_games_1_1_voice_pro_1_1_voice_detector" ],
    [ "WelcomeDialog", "class_frostweep_games_1_1_voice_pro_1_1_welcome_dialog.html", null ]
];