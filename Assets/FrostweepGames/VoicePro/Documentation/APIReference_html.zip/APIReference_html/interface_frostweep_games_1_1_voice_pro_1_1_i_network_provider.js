var interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider =
[
    [ "Dispose", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#adf9bb51fb0507f0cb8e0508a98874e85", null ],
    [ "GetConnectionToServer", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a384914ef0622fd98bb61422cacaec48c", null ],
    [ "GetCurrentRoomName", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a372e33d5e8ef9650f066355fa7d24e3b", null ],
    [ "GetNetworkState", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a6ac802aa5fa051e607c8ad754677ae2e", null ],
    [ "Init", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#af7e52b4887ac0cc25bccde6d86a0801d", null ],
    [ "SendNetworkData", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a75d576d5bb45ec3dfb0821a1159d66d7", null ],
    [ "NetworkDataReceivedEvent", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html#a2141efeb7100d4a84347c85081569427", null ]
];