var dir_af3aaffdeaf3a7ee2af9b6d5900c237a =
[
    [ "Attributes", "dir_3cb1f3727b60d3d39fe2173a1f7eaabe.html", "dir_3cb1f3727b60d3d39fe2173a1f7eaabe" ],
    [ "Compressor.cs", "_compressor_8cs.html", [
      [ "Compressor", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html", "class_frostweep_games_1_1_voice_pro_1_1_compressor" ]
    ] ],
    [ "VoiceDetector.cs", "_voice_detector_8cs.html", [
      [ "VoiceDetector", "class_frostweep_games_1_1_voice_pro_1_1_voice_detector.html", "class_frostweep_games_1_1_voice_pro_1_1_voice_detector" ]
    ] ]
];