var dir_ab5696bc9d8fd447402a56e883529346 =
[
    [ "AudioConverter.cs", "_audio_converter_8cs.html", [
      [ "AudioConverter", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter.html", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter" ]
    ] ]
];