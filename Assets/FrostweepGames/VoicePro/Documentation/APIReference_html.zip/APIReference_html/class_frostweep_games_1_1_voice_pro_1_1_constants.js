var class_frostweep_games_1_1_voice_pro_1_1_constants =
[
    [ "ChunkSize", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a3262a82807213b29dd92ffe21d1ca4ef", null ],
    [ "RecordingTime", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a3c61153852ba999de383e3f03df71521", null ],
    [ "SampleRate", "class_frostweep_games_1_1_voice_pro_1_1_constants.html#a9e3421217d2a724bb97500f45f19cdd6", null ]
];