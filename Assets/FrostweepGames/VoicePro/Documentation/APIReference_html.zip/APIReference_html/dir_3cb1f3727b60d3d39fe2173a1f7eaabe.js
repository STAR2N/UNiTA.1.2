var dir_3cb1f3727b60d3d39fe2173a1f7eaabe =
[
    [ "ReadOnlyAttribute.cs", "_read_only_attribute_8cs.html", [
      [ "ReadOnlyAttribute", "class_frostweep_games_1_1_plugins_1_1_read_only_attribute.html", null ]
    ] ]
];