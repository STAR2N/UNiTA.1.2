var class_frostweep_games_1_1_voice_pro_1_1_audio_converter =
[
    [ "ByteToFloat", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter.html#a03dac0401e2711f76911e3fbaaf24a56", null ],
    [ "FloatToByte", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter.html#ad5d149c3d51669b720781fd7aa4a169d", null ]
];