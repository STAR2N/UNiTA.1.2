var class_frostweep_games_1_1_voice_pro_1_1_network_router =
[
    [ "NetworkParameters", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_parameters.html", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_parameters" ],
    [ "GetConnectionToServer", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#aef8b3b4136a67cba6b339c8f14199f66", null ],
    [ "GetCurrentRoomName", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a2ce15903e968d5160432ad955a8bf432", null ],
    [ "GetNetworkState", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a88e6e6a3c31ece780c4f80f7b3b2ad79", null ],
    [ "Register", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a647f4175387305677b0c3ba7b86b6193", null ],
    [ "SendNetworkData", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#ac3f58e9b10c1e3647c7e51aec70ad8ce", null ],
    [ "Unregister", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a0d9191d9f75e229d27b3d163f2c66356", null ],
    [ "Instance", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a3a6554dc932a54ed0b82fa2c1eb4657e", null ],
    [ "NetworkType", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#ad3df36e8cd9f947199d7fb1322a4aea7", null ],
    [ "NetworkDataReceivedEvent", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html#a7f2e629390d1e107daaa79118e80a595", null ]
];