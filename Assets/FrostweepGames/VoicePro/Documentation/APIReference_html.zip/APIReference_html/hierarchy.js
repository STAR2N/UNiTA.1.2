var hierarchy =
[
    [ "FrostweepGames.VoicePro.AudioConverter", "class_frostweep_games_1_1_voice_pro_1_1_audio_converter.html", null ],
    [ "FrostweepGames.VoicePro.Compressor", "class_frostweep_games_1_1_voice_pro_1_1_compressor.html", null ],
    [ "FrostweepGames.VoicePro.Constants", "class_frostweep_games_1_1_voice_pro_1_1_constants.html", null ],
    [ "EditorWindow", null, [
      [ "FrostweepGames.VoicePro.WelcomeDialog", "class_frostweep_games_1_1_voice_pro_1_1_welcome_dialog.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.Enumerators", "class_frostweep_games_1_1_voice_pro_1_1_enumerators.html", null ],
    [ "FrostweepGames.VoicePro.INetworkActor", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html", null ],
    [ "FrostweepGames.VoicePro.INetworkProvider", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html", null ],
    [ "MonoBehaviour", null, [
      [ "FrostweepGames.VoicePro.Listener", "class_frostweep_games_1_1_voice_pro_1_1_listener.html", null ],
      [ "FrostweepGames.VoicePro.Recorder", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.NetworkRouter.NetworkParameters", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_parameters.html", null ],
    [ "FrostweepGames.VoicePro.NetworkRouter", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html", null ],
    [ "PropertyAttribute", null, [
      [ "FrostweepGames.Plugins.ReadOnlyAttribute", "class_frostweep_games_1_1_plugins_1_1_read_only_attribute.html", null ]
    ] ],
    [ "FrostweepGames.VoicePro.Speaker", "class_frostweep_games_1_1_voice_pro_1_1_speaker.html", null ],
    [ "FrostweepGames.VoicePro.VoiceDetector", "class_frostweep_games_1_1_voice_pro_1_1_voice_detector.html", null ]
];