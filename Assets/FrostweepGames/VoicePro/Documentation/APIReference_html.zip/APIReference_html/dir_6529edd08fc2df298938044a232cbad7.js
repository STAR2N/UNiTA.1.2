var dir_6529edd08fc2df298938044a232cbad7 =
[
    [ "WelcomeDialog.cs", "_welcome_dialog_8cs.html", [
      [ "WelcomeDialog", "class_frostweep_games_1_1_voice_pro_1_1_welcome_dialog.html", null ]
    ] ]
];