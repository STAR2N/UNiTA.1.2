var dir_17790824fb8be72908c1fa38cb1cf0c1 =
[
    [ "Providers", "dir_9ab1ce26ff4f56a319907b45b40779d6.html", "dir_9ab1ce26ff4f56a319907b45b40779d6" ],
    [ "INetworkActor.cs", "_i_network_actor_8cs.html", [
      [ "INetworkActor", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor" ]
    ] ],
    [ "INetworkProvider.cs", "_i_network_provider_8cs.html", [
      [ "INetworkProvider", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider.html", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_provider" ]
    ] ],
    [ "NetworkRouter.cs", "_network_router_8cs.html", [
      [ "NetworkRouter", "class_frostweep_games_1_1_voice_pro_1_1_network_router.html", "class_frostweep_games_1_1_voice_pro_1_1_network_router" ],
      [ "NetworkParameters", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_parameters.html", "class_frostweep_games_1_1_voice_pro_1_1_network_router_1_1_network_parameters" ]
    ] ]
];