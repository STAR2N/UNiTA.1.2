var interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor =
[
    [ "Id", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#afda6329a02f4c9b4fa750b0cb8643572", null ],
    [ "Name", "interface_frostweep_games_1_1_voice_pro_1_1_i_network_actor.html#a5f59f22cf75a9fe49da155b2583d45e8", null ]
];