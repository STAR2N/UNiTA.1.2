var class_frostweep_games_1_1_voice_pro_1_1_recorder =
[
    [ "RefreshMicrophones", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a1096dfa5011bcacdb390e7248ddbdd51", null ],
    [ "SetMicrophone", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#ab41d36f5fe66d2768971f78c23c48ca4", null ],
    [ "StartRecord", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a14e05532fd733019d3cac54700de5aa2", null ],
    [ "StopRecord", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#aee9df03bd0d507199f0355f02a9aaba7", null ],
    [ "debugEcho", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a6a0fea62689917ffb546f63485156ee5", null ],
    [ "recording", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a69a891d6477d789f8078c285b87b7201", null ],
    [ "reliableTransmission", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a9a89764a140f2977827e2d8041619d4f", null ],
    [ "voiceDetectionEnabled", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a1daba4677d622c7b69fa4ee18b57ce8f", null ],
    [ "voiceDetectionThreshold", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a96976a319f7860643dc833bf31211c1e", null ],
    [ "RecordEndedEvent", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a5d55c09afdb9c98522b510a36dca12f4", null ],
    [ "RecordFailedEvent", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a06429e395656d4b4a8650ab1b4c5fb1f", null ],
    [ "RecordStartedEvent", "class_frostweep_games_1_1_voice_pro_1_1_recorder.html#a23244381313617fcc8ba16747a08165d", null ]
];