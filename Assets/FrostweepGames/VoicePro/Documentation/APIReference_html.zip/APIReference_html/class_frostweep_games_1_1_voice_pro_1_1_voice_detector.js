var class_frostweep_games_1_1_voice_pro_1_1_voice_detector =
[
    [ "IsVoiceDetected", "class_frostweep_games_1_1_voice_pro_1_1_voice_detector.html#a9924d221728e924ac2c0087812ac6fd8", null ]
];