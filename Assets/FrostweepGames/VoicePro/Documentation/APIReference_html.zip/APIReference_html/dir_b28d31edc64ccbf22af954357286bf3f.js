var dir_b28d31edc64ccbf22af954357286bf3f =
[
    [ "Constants.cs", "_constants_8cs.html", [
      [ "Constants", "class_frostweep_games_1_1_voice_pro_1_1_constants.html", "class_frostweep_games_1_1_voice_pro_1_1_constants" ]
    ] ],
    [ "Enumerators.cs", "_enumerators_8cs.html", [
      [ "Enumerators", "class_frostweep_games_1_1_voice_pro_1_1_enumerators.html", "class_frostweep_games_1_1_voice_pro_1_1_enumerators" ]
    ] ]
];